
import React from 'react';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Features from '@/components/Features';
import Solutions from '@/components/Solutions';
import Testimonials from '@/components/Testimonials';
import Pricing from '@/components/Pricing';
import Footer from '@/components/Footer';

function App() {
  return (
    <>
      <Helmet>
        <title>InnoCraft | Uw All-in-One Bedrijfssoftware</title>
        <meta name="description" content="Transformeer uw bedrijf met onze uitgebreide suite van beheerapplicaties. CRM, ERP, eCommerce en meer - alles geïntegreerd in één krachtig platform." />
        <meta property="og:title" content="InnoCraft | Uw All-in-One Bedrijfssoftware" />
        <meta property="og:description" content="Transformeer uw bedrijf met onze uitgebreide suite van beheerapplicaties. CRM, ERP, eCommerce en meer - alles geïntegreerd in één krachtig platform." />
      </Helmet>
      
      <div className="min-h-screen bg-white">
        <Header />
        <Hero />
        <Features />
        <Solutions />
        <Testimonials />
        <Pricing />
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;
