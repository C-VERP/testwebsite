
import React from 'react';
import { motion } from 'framer-motion';
import { Play, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Hero = () => {
  const handleCTAClick = (action) => {
    toast({
      title: "🚧 Actie Functie",
      description: "Deze functie is nog niet geïmplementeerd, maar geen zorgen! Je kunt het aanvragen in je volgende prompt! 🚀"
    });
  };

  return (
    <section className="pt-24 pb-16 bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-5xl lg:text-6xl font-bold leading-tight"
              >
                Laat uw bedrijf groeien met de{' '}
                <span className="gradient-text">alles-in-één</span>{' '}
                bedrijfssuite
              </motion.h1>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-xl text-gray-600 leading-relaxed"
              >
                Sluit u aan bij miljoenen bedrijven wereldwijd die onze geïntegreerde suite van applicaties gebruiken. 
                Van CRM tot eCommerce, boekhouding tot projectmanagement - alles wat u nodig heeft op één plek.
              </motion.p>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button 
                onClick={() => handleCTAClick('Start Gratis Proefperiode')}
                size="lg"
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-semibold"
              >
                Start Gratis Proefperiode
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                onClick={() => handleCTAClick('Bekijk Demo')}
                variant="outline"
                size="lg"
                className="border-purple-200 text-purple-600 hover:bg-purple-50 px-8 py-4 text-lg font-semibold"
              >
                <Play className="mr-2 h-5 w-5" />
                Bekijk Demo
              </Button>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="flex items-center space-x-8 text-sm text-gray-500"
            >
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">7M+</span>
                <span className="ml-1">gebruikers wereldwijd</span>
              </div>
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">50+</span>
                <span className="ml-1">geïntegreerde apps</span>
              </div>
              <div className="flex items-center">
                <span className="font-semibold text-gray-900">4.8/5</span>
                <span className="ml-1">klantbeoordeling</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Content - Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative z-10">
              <img  
                alt="Bedrijfsdashboard-interface met analyses en beheertools"
                className="w-full h-auto rounded-2xl shadow-2xl hover-lift"
               src="https://images.unsplash.com/photo-1516383274235-5f42d6c6426d" />
            </div>
            
            {/* Floating Elements */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg p-4 z-20"
            >
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm font-medium">Verkoop +24%</span>
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 4, repeat: Infinity }}
              className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-4 z-20"
            >
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="text-sm font-medium">Nieuwe Orders: 47</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
