
import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Sarah Jansen',
      role: 'CEO, TechStart BV',
      company: 'TechStart BV',
      content: 'Dit platform heeft de manier waarop we ons bedrijf beheren volledig veranderd. De integratie tussen alle modules is naadloos en onze productiviteit is met 40% gestegen.',
      rating: 5,
      avatar: 'Professionele zakenvrouw CEO in moderne kantooromgeving'
    },
    {
      name: 'Michael de Vries',
      role: 'Operationeel Directeur',
      company: 'Wereldwijde Retail Co.',
      content: 'We zijn overgestapt van meerdere losse tools naar deze alles-in-één oplossing. De tijdsbesparing en het verbeterde overzicht over onze operaties zijn ongelooflijk.',
      rating: 5,
      avatar: 'Aziatische zakenman in een zakelijke omgeving'
    },
    {
      name: 'Emily de Boer',
      role: 'Oprichter',
      company: 'Creatief Bureau',
      content: 'Als groeiend bureau hadden we iets nodig dat met ons mee kon schalen. Dit platform heeft alles wat we nodig hebben - van projectmanagement tot klantfacturering.',
      rating: 5,
      avatar: 'Jonge vrouwelijke ondernemer in een creatieve werkruimte'
    }
  ];

  const stats = [
    { number: '7M+', label: 'Actieve Gebruikers' },
    { number: '150+', label: 'Landen' },
    { number: '99.9%', label: 'Uptime' },
    { number: '4.8/5', label: 'Klantbeoordeling' }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Vertrouwd door bedrijven{' '}
            <span className="gradient-text">wereldwijd</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Sluit u aan bij miljoenen tevreden klanten die hun bedrijfsvoering hebben getransformeerd met ons platform.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-20"
        >
          {stats.map((stat, index) => (
            <div key={stat.label} className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-4xl lg:text-5xl font-bold gradient-text mb-2"
              >
                {stat.number}
              </motion.div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Testimonials */}
        <div className="grid lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-gray-50 rounded-2xl p-8 hover:bg-white hover:shadow-xl transition-all duration-300 hover-lift relative">
                <Quote className="absolute top-6 right-6 h-8 w-8 text-purple-200 group-hover:text-purple-300 transition-colors" />
                
                {/* Rating */}
                <div className="flex items-center mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-gray-700 mb-8 leading-relaxed text-lg">
                  "{testimonial.content}"
                </p>

                {/* Author */}
                <div className="flex items-center">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                    <img  
                      alt={`${testimonial.name} profielfoto`}
                      className="w-full h-full object-cover"
                     src="https://images.unsplash.com/photo-1649399045831-40bfde3ef21d" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                    <div className="text-sm text-purple-600 font-medium">{testimonial.company}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 rounded-2xl p-12 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-3xl lg:text-4xl font-bold mb-4">
                Klaar om u aan te sluiten?
              </h3>
              <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
                Start vandaag nog uw gratis proefperiode en ontdek waarom miljoenen bedrijven voor ons platform kiezen.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="bg-white text-purple-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors text-lg">
                  Start Gratis Proefperiode
                </button>
                <button className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-purple-600 transition-colors text-lg">
                  Plan een Demo
                </button>
              </div>
            </div>
            
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full -translate-x-20 -translate-y-20"></div>
              <div className="absolute bottom-0 right-0 w-60 h-60 bg-white rounded-full translate-x-30 translate-y-30"></div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonials;
