
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Facebook, 
  Twitter, 
  Linkedin, 
  Instagram, 
  Mail, 
  Phone, 
  MapPin 
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Footer = () => {
  const handleLinkClick = (item) => {
    toast({
      title: "🚧 Navigatie Functie",
      description: "Deze functie is nog niet geïmplementeerd, maar geen zorgen! Je kunt het aanvragen in je volgende prompt! 🚀"
    });
  };

  const footerSections = [
    {
      title: 'Product',
      links: ['Functies', 'Prijzen', 'Beveiliging', 'Integraties', 'API', 'Mobiele Apps']
    },
    {
      title: 'Oplossingen',
      links: ['Klein Bedrijf', 'Enterprise', 'eCommerce', 'Productie', 'Retail', 'Gezondheidszorg']
    },
    {
      title: 'Bronnen',
      links: ['Documentatie', 'Helpcentrum', 'Community', 'Blog', 'Webinars', 'Casestudy\'s']
    },
    {
      title: 'Bedrijf',
      links: ['Over Ons', 'Carrières', 'Pers', 'Partners', 'Contact', 'Juridisch']
    }
  ];

  const socialLinks = [
    { icon: Facebook, name: 'Facebook' },
    { icon: Twitter, name: 'Twitter' },
    { icon: Linkedin, name: 'LinkedIn' },
    { icon: Instagram, name: 'Instagram' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-6 gap-8">
            {/* Company Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="lg:col-span-2"
            >
              <div className="mb-6">
                <span className="text-2xl font-bold gradient-text">InnoCraft</span>
              </div>
              
              <p className="text-gray-400 mb-6 leading-relaxed">
                Bedrijven wereldwijd versterken met geïntegreerde softwareoplossingen. 
                Van startups tot enterprises, wij helpen u operaties te stroomlijnen en groei te stimuleren.
              </p>

              {/* Contact Info */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center text-gray-400">
                  <Mail className="h-5 w-5 mr-3" />
                  <span>hallo@innocraft.com</span>
                </div>
                <div className="flex items-center text-gray-400">
                  <Phone className="h-5 w-5 mr-3" />
                  <span>+31 (20) 123-4567</span>
                </div>
                <div className="flex items-center text-gray-400">
                  <MapPin className="h-5 w-5 mr-3" />
                  <span>Amsterdam, NL</span>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <motion.button
                    key={social.name}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    onClick={() => handleLinkClick(social.name)}
                    className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-purple-600 transition-colors"
                  >
                    <social.icon className="h-5 w-5" />
                  </motion.button>
                ))}
              </div>
            </motion.div>

            {/* Footer Links */}
            {footerSections.map((section, sectionIndex) => (
              <motion.div
                key={section.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: sectionIndex * 0.1 }}
                viewport={{ once: true }}
              >
                <span className="text-lg font-semibold mb-6 block">{section.title}</span>
                <ul className="space-y-3">
                  {section.links.map((link, linkIndex) => (
                    <li key={link}>
                      <button
                        onClick={() => handleLinkClick(link)}
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                        {link}
                      </button>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Newsletter Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="border-t border-gray-800 py-8"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <span className="text-xl font-semibold mb-2 block">Blijf op de hoogte</span>
              <p className="text-gray-400">
                Ontvang het laatste nieuws, updates en tips in uw inbox.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="Voer uw e-mailadres in"
                className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={() => handleLinkClick('Abonneren')}
                className="px-6 py-3 bg-purple-600 hover:bg-purple-700 rounded-lg font-semibold transition-colors"
              >
                Abonneren
              </button>
            </div>
          </div>
        </motion.div>

        {/* Bottom Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="border-t border-gray-800 py-8"
        >
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 InnoCraft. Alle rechten voorbehouden.
            </p>
            
            <div className="flex space-x-6 mt-4 md:mt-0">
              <button
                onClick={() => handleLinkClick('Privacybeleid')}
                className="text-gray-400 hover:text-white text-sm transition-colors"
              >
                Privacybeleid
              </button>
              <button
                onClick={() => handleLinkClick('Servicevoorwaarden')}
                className="text-gray-400 hover:text-white text-sm transition-colors"
              >
                Servicevoorwaarden
              </button>
              <button
                onClick={() => handleLinkClick('Cookiebeleid')}
                className="text-gray-400 hover:text-white text-sm transition-colors"
              >
                Cookiebeleid
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
};

export default Footer;
