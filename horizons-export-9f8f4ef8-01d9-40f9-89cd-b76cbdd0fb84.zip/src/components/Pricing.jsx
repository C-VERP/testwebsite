
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Pricing = () => {
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      name: 'Starter',
      description: 'Perfect voor kleine bedrijven die net beginnen',
      monthlyPrice: 29,
      annualPrice: 290,
      features: [
        'Tot 5 gebruikers',
        'Basis CRM',
        'Projectbeheer',
        'E-mailondersteuning',
        '10GB Opslag',
        'Toegang tot mobiele app'
      ],
      limitations: [
        'Geavanceerde Analyse',
        'Aangepaste Workflows',
        'API-toegang',
        'Prioriteitsondersteuning'
      ],
      popular: false,
      color: 'border-gray-200'
    },
    {
      name: 'Professioneel',
      description: 'Ideaal voor groeiende bedrijven',
      monthlyPrice: 79,
      annualPrice: 790,
      features: [
        'Tot 25 gebruikers',
        'Volledige CRM Suite',
        'Geavanceerd Projectbeheer',
        'eCommerce Integratie',
        'Geavanceerde Analyse',
        'Aangepaste Workflows',
        'Prioriteitsondersteuning',
        '100GB Opslag',
        'API-toegang'
      ],
      limitations: [
        'Multi-Company Beheer',
        'White-label Opties'
      ],
      popular: true,
      color: 'border-purple-500'
    },
    {
      name: 'Enterprise',
      description: 'Voor grote organisaties met complexe behoeften',
      monthlyPrice: 199,
      annualPrice: 1990,
      features: [
        'Onbeperkt aantal gebruikers',
        'Volledige Toegang tot Suite',
        'Multi-Company Beheer',
        'Geavanceerde Beveiliging',
        'Aangepaste Integraties',
        'Toegewijde Ondersteuning',
        'White-label Opties',
        'Onbeperkte Opslag',
        'SLA Garantie',
        'Aangepaste Training'
      ],
      limitations: [],
      popular: false,
      color: 'border-gray-200'
    }
  ];

  const handlePlanSelect = (planName) => {
    toast({
      title: `🚧 ${planName} Plan`,
      description: "Deze functie is nog niet geïmplementeerd, maar geen zorgen! Je kunt het aanvragen in je volgende prompt! 🚀"
    });
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Eenvoudige, transparante{' '}
            <span className="gradient-text">prijzen</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            Kies het perfecte plan voor uw bedrijf. Alle plannen bevatten onze kernfuncties zonder verborgen kosten.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4">
            <span className={`text-lg font-medium ${!isAnnual ? 'text-purple-600' : 'text-gray-500'}`}>
              Maandelijks
            </span>
            <button
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                isAnnual ? 'bg-purple-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  isAnnual ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`text-lg font-medium ${isAnnual ? 'text-purple-600' : 'text-gray-500'}`}>
              Jaarlijks
            </span>
            {isAnnual && (
              <span className="bg-green-100 text-green-800 text-sm font-medium px-3 py-1 rounded-full">
                Bespaar 17%
              </span>
            )}
          </div>
        </motion.div>

        {/* Pricing Cards */}
        <div className="grid lg:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift border-2 ${plan.color} ${
                plan.popular ? 'scale-105' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-purple-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                    Meest Populair
                  </span>
                </div>
              )}

              <div className="p-8">
                {/* Plan Header */}
                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-6">{plan.description}</p>
                  
                  <div className="mb-6">
                    <span className="text-5xl font-bold text-gray-900">
                      €{isAnnual ? plan.annualPrice : plan.monthlyPrice}
                    </span>
                    <span className="text-gray-600 ml-2">
                      /{isAnnual ? 'jaar' : 'maand'}
                    </span>
                  </div>

                  <Button
                    onClick={() => handlePlanSelect(plan.name)}
                    className={`w-full py-3 text-lg font-semibold ${
                      plan.popular
                        ? 'bg-purple-600 hover:bg-purple-700 text-white'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                    }`}
                  >
                    {plan.popular ? 'Start Gratis Proefperiode' : 'Begin Nu'}
                  </Button>
                </div>

                {/* Features */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900 mb-4">Wat is inbegrepen:</h4>
                  
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center">
                      <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}

                  {plan.limitations.length > 0 && (
                    <>
                      <div className="border-t border-gray-200 pt-4 mt-6">
                        <h4 className="font-semibold text-gray-900 mb-4">Niet inbegrepen:</h4>
                        {plan.limitations.map((limitation, idx) => (
                          <div key={idx} className="flex items-center">
                            <X className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                            <span className="text-gray-500">{limitation}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* FAQ Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <h3 className="text-2xl font-bold mb-8">Veelgestelde Vragen</h3>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {[
              {
                question: 'Kan ik op elk moment van plan wisselen?',
                answer: 'Ja, u kunt uw plan op elk moment upgraden of downgraden. Wijzigingen worden onmiddellijk van kracht.'
              },
              {
                question: 'Is er een gratis proefperiode?',
                answer: 'Ja, we bieden een gratis proefperiode van 14 dagen voor alle plannen. Geen creditcard nodig om te starten.'
              },
              {
                question: 'Welke betaalmethoden accepteert u?',
                answer: 'We accepteren alle gangbare creditcards, PayPal en bankoverschrijvingen voor jaarplannen.'
              },
              {
                question: 'Biedt u kortingen voor non-profitorganisaties?',
                answer: 'Ja, we bieden speciale prijzen voor gekwalificeerde non-profitorganisaties. Neem contact met ons op voor details.'
              }
            ].map((faq, index) => (
              <div key={index} className="text-left bg-white p-6 rounded-xl shadow-md">
                <h4 className="font-semibold text-gray-900 mb-2">{faq.question}</h4>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
