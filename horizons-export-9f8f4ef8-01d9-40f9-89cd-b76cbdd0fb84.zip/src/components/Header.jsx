
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Menu, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavClick = (item) => {
    toast({
      title: "🚧 Navigatie Functie",
      description: "Deze functie is nog niet geïmplementeerd, maar geen zorgen! Je kunt het aanvragen in je volgende prompt! 🚀"
    });
  };

  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 w-full bg-white/95 backdrop-blur-md border-b border-gray-200 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="text-2xl font-bold gradient-text">InnoCraft</div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <div className="relative group">
              <button 
                onClick={() => handleNavClick('Apps')}
                className="flex items-center text-gray-700 hover:text-purple-600 transition-colors"
              >
                Apps <ChevronDown className="ml-1 h-4 w-4" />
              </button>
            </div>
            <button 
              onClick={() => handleNavClick('Branches')}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Branches
            </button>
            <button 
              onClick={() => handleNavClick('Diensten')}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Diensten
            </button>
            <button 
              onClick={() => handleNavClick('Prijzen')}
              className="text-gray-700 hover:text-purple-600 transition-colors"
            >
              Prijzen
            </button>
          </nav>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => handleNavClick('Inloggen')}
              className="text-gray-700 hover:text-purple-600"
            >
              Inloggen
            </Button>
            <Button 
              onClick={() => handleNavClick('Start Gratis')}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Start Gratis
            </Button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-purple-600"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden py-4 border-t border-gray-200"
          >
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => handleNavClick('Apps')}
                className="text-left text-gray-700 hover:text-purple-600 transition-colors"
              >
                Apps
              </button>
              <button 
                onClick={() => handleNavClick('Branches')}
                className="text-left text-gray-700 hover:text-purple-600 transition-colors"
              >
                Branches
              </button>
              <button 
                onClick={() => handleNavClick('Diensten')}
                className="text-left text-gray-700 hover:text-purple-600 transition-colors"
              >
                Diensten
              </button>
              <button 
                onClick={() => handleNavClick('Prijzen')}
                className="text-left text-gray-700 hover:text-purple-600 transition-colors"
              >
                Prijzen
              </button>
              <div className="pt-4 border-t border-gray-200">
                <Button 
                  variant="ghost" 
                  onClick={() => handleNavClick('Inloggen')}
                  className="w-full justify-start text-gray-700 hover:text-purple-600 mb-2"
                >
                  Inloggen
                </Button>
                <Button 
                  onClick={() => handleNavClick('Start Gratis')}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                >
                  Start Gratis
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
};

export default Header;
