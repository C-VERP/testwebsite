
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  ShoppingCart, 
  BarChart3, 
  Calendar, 
  MessageSquare, 
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import { toast } from '@/components/ui/use-toast';

const Features = () => {
  const features = [
    {
      icon: Users,
      title: 'CRM & Verkoop',
      description: 'Beheer leads, volg kansen en sluit sneller deals met ons krachtige CRM-systeem.',
      color: 'bg-blue-500'
    },
    {
      icon: ShoppingCart,
      title: 'eCommerce',
      description: 'Bouw en beheer uw online winkel met geïntegreerd voorraadbeheer en betalingsverwerking.',
      color: 'bg-green-500'
    },
    {
      icon: BarChart3,
      title: 'Boekhouding',
      description: 'Compleet financieel beheer met facturering, onkosten en real-time rapportage.',
      color: 'bg-purple-500'
    },
    {
      icon: Calendar,
      title: 'Projectbeheer',
      description: 'Plan, volg en lever projecten op tijd met samenwerkingstools en urenstaten.',
      color: 'bg-orange-500'
    },
    {
      icon: MessageSquare,
      title: 'Communicatie',
      description: 'Blijf verbonden met geïntegreerde chat, videogesprekken en teamsamenwerking.',
      color: 'bg-pink-500'
    },
    {
      icon: Zap,
      title: 'Automatisering',
      description: 'Stroomlijn workflows met krachtige automatiseringstools en aangepaste bedrijfsregels.',
      color: 'bg-yellow-500'
    },
    {
      icon: Shield,
      title: 'Beveiliging',
      description: 'Beveiliging op bedrijfsniveau met gegevensversleuteling, toegangscontroles en compliance.',
      color: 'bg-red-500'
    },
    {
      icon: Globe,
      title: 'Multi-Company',
      description: 'Beheer meerdere bedrijven en dochterondernemingen vanuit één, verenigd platform.',
      color: 'bg-indigo-500'
    }
  ];

  const handleFeatureClick = (feature) => {
    toast({
      title: `🚧 ${feature} Functie`,
      description: "Deze functie is nog niet geïmplementeerd, maar geen zorgen! Je kunt het aanvragen in je volgende prompt! 🚀"
    });
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl lg:text-5xl font-bold mb-6">
            Alles wat u nodig heeft om uw{' '}
            <span className="gradient-text">bedrijf</span> te runnen
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Onze uitgebreide suite van bedrijfsapplicaties werken naadloos samen, 
            waardoor u de kracht heeft om elk aspect van uw bedrijf vanaf één platform te beheren.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              onClick={() => handleFeatureClick(feature.title)}
              className="group cursor-pointer"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift border border-gray-100">
                <div className={`${feature.color} w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                
                <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:text-purple-600 transition-colors">
                  {feature.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Klaar om uw bedrijf te transformeren?
            </h3>
            <p className="text-lg mb-6 opacity-90">
              Sluit u aan bij duizenden bedrijven die ons platform al gebruiken om hun activiteiten te stroomlijnen.
            </p>
            <button 
              onClick={() => handleFeatureClick('Begin Vandaag')}
              className="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Begin Vandaag
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Features;
